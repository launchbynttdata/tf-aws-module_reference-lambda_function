def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": "examples/source_from_zip"
    }